# ZeldaApparatus
This mod gives the apparatus a random 1 in 5 chance for not turning off the lights and then playing the [Zelda Oot secret sound.](https://www.youtube.com/watch?v=9d3qCPcMgH4)